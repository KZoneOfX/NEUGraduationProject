carbon-identity
===============

---

|  Branch | Build Status |
| :------------ |:-------------
| master      | [![Build Status](https://wso2.org/jenkins/job/carbon-identity/badge/icon)](https://wso2.org/jenkins/job/carbon-identity) |


---

This repository is no longer used for development. Current developments are done in following repositories.

1. https://github.com/wso2/identity-framework
2. https://github.com/wso2-extensions?utf8=%E2%9C%93&query=identity

This repository contains the source code of modules used for WSO2 Idenity Server 5.1.0 and previous releases. Some of
these modules are used by other products of the the platform as well.

Service Stubs, Components and Features of each module is contained in this repository.
